import { View, Text, StyleSheet, Animated, TouchableOpacity} from 'react-native'
import React, { useState } from 'react'
import { grey1 } from '../global'
import { AntDesign } from '@expo/vector-icons'
import { useDispatch, useSelector } from 'react-redux'

export default function QuantityAnimate({id, food, restaurant}) {

    const opacity = useState(new Animated.Value(0))[0]
    const marginLeft = useState(new Animated.Value(0))[0]
    const [visible, setVisible] = useState(false)
    const dispatch = useDispatch();
    let count = useSelector(state => state.cartReducer).filter((food)=>food.id === id).length

    const fadeIn = ()=>{
        Animated.sequence([
            Animated.timing(marginLeft, {
                toValue: 50,
                duration: 100,
                useNativeDriver: false
            }),
             Animated.timing(opacity, {
                toValue: 1,
                duration: 100,
                useNativeDriver: false
            }),
        ]).start()
         

        
    }
    
    if(visible){
    fadeIn()
    }
    const styles = StyleSheet.create({

        plus: {
            backgroundColor: grey1,
             
            height: 30,
            aspectRatio: 1,
            alignItems: "center",
            justifyContent: "center",
            borderRadius: 50,
         // position: "absolute",
         // zIndex: 1
           
        },
        plusText: {
            fontSize: 20,
           // padding: "auto",
           //borderWidth: 1,
           textAlign: "center",
          // borderWidth: 1,
          fontWeight: "bold"         
        },
        plus1: {
         //  opacity: opacity 
        }
    })

    


  return (
    <View style={{flexDirection: "row", alignItems:"center"}}>
        {!visible?<TouchableOpacity style={styles.plus} onPress={()=>{
           setVisible(true)
        }}>
          <Text style={styles.plusText}>+</Text>

        </TouchableOpacity>:<></>}


        {visible? <Animated.View style={[{
            opacity: opacity,
           // marginLeft: marginLeft
            
        }]}>
       <TouchableOpacity onPress={()=>{
           
           if(count)
           dispatch({
            type: 'REMOVE_FROM_CARD',
  
            payload: id
          });
  
        }}>
                   <AntDesign name="minuscircle" size={25} color="black" style={styles.plus2} />

       </TouchableOpacity>


        </Animated.View>:<></>}




       {visible?<View style={{ position: "absolute", left: 45}}>
        <Text style={{
         // padding: 5,
        }}>{count}</Text>
      </View>:<></>}

 


        {visible?<Animated.View style={[{
           // opacity: opacity,
            marginLeft: marginLeft,
             
        }]}>
             <TouchableOpacity onPress={()=>{
          
          dispatch({
            type: 'ADD_TO_CART',
            payload: {
              ...food,
              restaurantName: restaurant.name,
              restaurantImage: restaurant.image_url,
              restaurant: restaurant
              
            }
          });


        }}>
                         <AntDesign name="pluscircle" size={25} color="black" style={styles.plus1} />

        </TouchableOpacity>
        </Animated.View>:<></>}
       
     </View>

    
  )

   
}

 